import httplib
import urllib,urllib2,re,sys
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
import xml.dom.minidom
import base64
import xbmc
import xbmcaddon,xbmcplugin,xbmcgui
import socket
from bs4 import BeautifulSoup
##from BeautifulSoup import BeautifulSoup

pl=xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
pl.clear()
homelink ='http://www.phatam.com/video/index.html'
logo='http://www.phatam.com/video/templates/ngodung/images/logo.png'


def home():
    addDir('Chuyen Muc',homelink,3,logo)
    addDir('Tac gia',homelink,4,logo)
    addDir('New Videos',homelink,7,logo)


def playVideo(url):
    try:
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_DVD)
        xbmcPlayer.play(url)

    except:pass

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
##        print u
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=logo, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,iconimage,mirror):
##        print url
##        print mirror
        if mirror.lower().find("youtube") != -1:
            u="plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid="+urllib.quote_plus(url).replace('?','')
            print u
        elif mirror.lower().find("picasaweb")!=-1:
            u=urllib.unquote_plus(url)##
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name })
        liz.setProperty('mimetype', 'video/x-msvideo')
##        liz.setProperty('IsPlayable', 'true')
##        contextMenuItems = []
##        liz.addContextMenuItems("Play All", replaceItems=True)
        pl.add(url, liz)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok

def Category(url):
    try:
        doc = urllib2.urlopen(url).read()
        soup = BeautifulSoup(doc)
        catedoc = soup.findAll('ul',id='ul_categories')
        soup = BeautifulSoup(str(catedoc[0]))
        catelinks = soup('a')
##        print catelinks
        for link in catelinks:
            lsoup = BeautifulSoup(str(link))
            lhref = lsoup('a')[0]['href']
            lname = lsoup('a')[0].contents[0]
            addDir(lname.encode("utf-8"),lhref.encode("utf-8"),1,logo)

    except:pass
def new_random(url):
    try:
        doc = urllib2.urlopen(url).read()
        soup = BeautifulSoup(doc)
        item = soup.findAll('div',{'class':'item'})

##        print str(len(item))
        for i in item:
            isoup = BeautifulSoup(str(i))
            ilink = BeautifulSoup(str(isoup('a',{'class':'song_name'})[0]))('a')[0]['href']
            iimage = isoup('img')[0]['src']
            ititle = isoup('span',{'class':'artist_name'})[0].contents[0]
##            print ilink


            addDir(ititle.encode("utf-8"),ilink.encode("utf-8"),2,iimage.encode("utf-8"))

    except:pass

def authors(url):
    try:
        doc = urllib2.urlopen(url).read()
        soup = BeautifulSoup(doc)
        audoc = soup.findAll('div',{'class':'list_left'})
##        more = soup.findAll('div',{'class':'xemthem'})
        soup = BeautifulSoup(str(audoc[0]))
        aulinks = soup('a')
        for link in aulinks:
            ausoup = BeautifulSoup(str(link))
            auhref = ausoup('a')[0]['href']
            auname = ausoup('a')[0].contents[0]

            addDir(auname.encode("utf-8"),auhref.encode("utf-8"),1,logo)

##        link = urllib2.urlopen(url).read()
        newlink = ''.join(doc.splitlines()).replace('\t','')
        match = re.compile('<div class="xemthem"><a href="(.+?)">(.+?)</a></div>').findall(newlink)
        for m in match:
            pl,pn = m
            addDir(pn,pl,6,logo)

##        morelink = more('a')[0]['href']
##        morename = more('a')[0].contents[0]
##        addDir(morename.encode("utf-8"),morelink.encode("utf-8"),6,logo)
##            print auhref+' - '+auname
    except:pass
def moreAuth(url):
    try:
        link = urllib2.urlopen(url).read()
        newlink = ''.join(link.splitlines()).replace('\t','')
        matchArea = re.compile('<div id="newvideos_results">(.+?)<a href="http://www.phatam.com/video/rss.php">').findall(newlink)
        match = re.compile('"250"><a href="(.+?)" title="(.+?)">').findall(matchArea[0])
        for m in match:
            al,an = m
            addDir(an,al,1,'')
        paging(url,6)

    except:pass
def index2(url):
    try:
        link = urllib2.urlopen(url).read()
        newlink = ''.join(link.splitlines()).replace('\t','')
        searchArea= re.compile('<div id="newvideos_results">(.+?)<td width="33%"><a href="http://www.phatam.com/video/rss.php').findall(newlink)
        linkarea = re.compile('"10"><a href="(.+?)"><img src="(.+?)" alt="(.+?)" class="tinythumb"').findall(searchArea[0])
        for content in linkarea:
            (vlink, vimage, vtitle)=content
##            print vtitle+'\n'+vlink+'\n'+vimage
            addDir(vtitle,vlink,2,vimage)

        paging(url,1)
    except:pass

def paging (url,mode):
    try:
        link = urllib2.urlopen(url).read()
        newlink = ''.join(link.splitlines()).replace('\t','')
        matchPageArea = re.compile('<div class="pagination">(.+?)<div id="footer">').findall(newlink)
        matchlinks = re.compile('<a href="(.+?)">(.+?)</a>').findall(matchPageArea[0])
        for match in matchlinks:
            plink,pname = match
            addDir(pname,'http://www.phatam.com/video/'+plink,mode,'')
##            print pname+' - '+plink


    except:pass

def index(url):
    try:
        req_headers = {
        'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13',
        'Referer': 'http://python.org'}
        request = urllib2.Request(url, headers=req_headers) # create a request object for the URL
        opener = urllib2.build_opener() # create an opener object
        response = opener.open(request) # open a connection and receive the http response headers + contents
        content = response.read()
        soup = BeautifulSoup(content)
        vlinks = soup.findAll('td', align="center")
        linklenght = len(vlinks)
        print 'Here we have: '+str(linklenght)+' links'
        for links in vlinks:
            print links
            try:
                vsoup = BeautifulSoup(str(links))
            except:pass
            vslinks = vsoup('a')[0]['href']
            vsimlinks = vsoup('img')[0]['src']
            vstitle = vsoup('img')[0]['alt']
##                print vstitle.encode("utf-8")+'\n'+vslinks.encode("utf-8")

            addDir(vstitle.encode("utf-8"),vslinks.encode("utf-8"),2,vsimlinks.encode("utf-8"))

        vpage = soup.findAll('div', {'class':'pagination'})
        soup = BeautifulSoup(str(vpage))
        vpagelinks = soup('a')
##        print vpagelinks
##        vpagelinkslen = len(vpagelinks)
        for page in vpagelinks:
            psoup = BeautifulSoup(str(page))
##            print psoup
##            pa = psoup('a')
##            pname = pa[0].contents[0]
            plink = psoup('a')[0]['href']
            pname = psoup('a')[0].contents[0]

            addDir(pname.encode("utf-8"),'http://www.phatam.com/video/'+plink.encode("utf-8"),1,'')

##            print pname+' - '+plink+'\n'


##        print vpagelinks

##        print vstitle+'\n'+vslinks+'\n'+vsimlinks+'\n'
    except:pass
##    except HTTPError, e:
##        print 'The server couldn\'t fulfill the request.'
##        print 'Error code: ', e.code
##    except URLError, e:
##        print 'We failed to reach a server.'
##        print 'Reason: ', e.reason

def getVideos(name,url):
    try:
        content = urllib2.urlopen(url).read()
        newlink = ''.join(content.splitlines()).replace('\t','')
        match = re.compile('<div id="Playerholder">(.+?)</object></div>').findall(newlink)
        matchcode = re.compile('value="http://www.youtube.com/v/(.+?)&hl=en').findall(match[0])
##        print matchcode[0]
##        print content
##        soup = BeautifulSoup(match)
####        print soup
##
##        divdoc = soup.findAll('div', id="Playerholder")
##        for doc in divdoc:
##            soup = BeautifulSoup(str(doc))
##            ylink = soup('param')[0]['value']
##            print type(ylink)
##            code = re.compile('/v/(.+?)&hl=').findall(ylink)

        addLink(name,matchcode[0],5,logo,'youtube')

##            print ylink+'\n'+code[0]+'\n'
##        print divdoc
    except:pass


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param



params=get_params()
url=None
name=None
mode=None
formvar=None
mirrorname=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        mirrorname=urllib.unquote_plus(params["mirrorname"])
except:
        pass

sysarg=str(sys.argv[1])
print "mode is:" + str(mode)
if mode==None or url==None or len(url)<1:
        home()
elif mode==1:
        index2(url)
elif mode==2:
        print url
        getVideos(name,url)
elif mode==3:
        Category(url)
elif mode==4:
        authors(url)
elif mode==5:
        playVideo(url)
elif mode==6:
        moreAuth(url)
elif mode==7:
        new_random(url)

xbmcplugin.endOfDirectory(int(sysarg))


##authors('http://www.phatam.com/video/index.html')
##Category('http://www.phatam.com/video/index.html')

##getVideos('http://www.phatam.com/video/thich-phuoc-tien/vo-nga-giua-doi-thuong-hd--video_804d3d856.html')
##getVideos('http://www.phatam.com/video/thich-dong-thanh/anh-sang-phat-phap-ky-36-video_87feaf701.html')
##index('http://phim.anhtrang.org/')
##index('https://www.coursera.org/courses')
##index('http://giaitri.com/')
##index('http://www.phatam.com/video/tac-gia-1-date-Th%C3%ADch_Ph%C6%B0%E1%BB%9Bc_Ti%E1%BA%BFn.html')
##index('http://www.phatam.com/video/browse-phap-thoai-videos-1-date.html')#Phap Thoai
##index('http://www.phatam.com/video/browse-kinh-chu-videos-1-date.html')#Kin Chu
##index('http://www.phatam.com/video/browse-sach-noi-videos-1-date.html')#Sach noi
##index('http://www.phatam.com/video/browse-tan-nhac-phat-giao-videos-1-date.html')#tan nhac
##index('http://www.phatam.com/video/browse-co-nhac-phat-giao-videos-1-date.html')#co nhac
##index('http://www.phatam.com/video/tac-gia-1-date-Ph%E1%BA%ADt_%C3%82m.html')
##index('http://www.phatam.com/video/tac-gia-1-date-Th%C3%ADch_Nh%E1%BA%ADt_T%E1%BB%AB.html')

##index('http://www.kinhphat.org')
##index('http://hdonline.vn/')
##index('http://www.uefa.com/video/weeklyedition/newsid=1856329.html')